import numpy as np
import datetime
import matplotlib
import pylab as plt
from matplotlib.dates import *

# Buoy
b=np.loadtxt('NDBC42040.txt')
# http://www.ndbc.noaa.gov/station_page.php?station=42040
bdates = np.array([date2num(datetime.datetime(yy,mm,dd,hh,mi)) for yy,mm,dd,hh,mi in zip(b[:,0].astype('i'),b[:,1].astype('i'),b[:,2].astype('i'),b[:,3].astype('i'),b[:,4].astype('i'))])
bhs=b[:,8]; # Hs

# ww3 model
m = np.loadtxt('tab50.ww3.st2',skiprows=3)
year=[]; month=[]; day=[];
for t in range(0,m.shape[0]):
	year=np.append(year,np.int(m[t,0].astype('i').astype('str')[0:4])).astype('i')
	month=np.append(month,np.int(m[t,0].astype('i').astype('str')[4:6])).astype('i')
	day=np.append(day,np.int(m[t,0].astype('i').astype('str')[6:8])).astype('i')

hour=m[:,1].astype('i')
mdates = np.array([date2num(datetime.datetime(yy,mm,dd,hh,mi)) for yy,mm,dd,hh,mi in zip(year,month,day,hour,np.zeros(hour.shape[0]).astype('i'))])
mhs=m[:,4]

#m = np.loadtxt('tab50.ww3.st2.norestart',skiprows=3)
#mhs2=m[:,4]
#m = np.loadtxt('tab50.ww3.st4b133',skiprows=3)
#mhs3=m[:,4]
#m = np.loadtxt('tab50.ww3.st4b170',skiprows=3)
#mhs4=m[:,4]

matplotlib.rcParams.update({'font.size': 12})
# Plot Buoy Data comparing the two locations
fig, ax = plt.subplots(figsize=(8,5))
ax.fill_between(bdates, 0., bhs, facecolor='k', alpha=0.3)
ax.plot(bdates,bhs,'k', label='buoy 42040',linewidth=2)
ax.plot(mdates,mhs,'r', label='ww3/CFSR ST2 default',linewidth=2);
#ax.plot(mdates,mhs2,'r--', label='ww3/CFSR ST2 no-restart',linewidth=2);
#ax.plot(mdates,mhs3,'b', label='ww3/CFSR ST4 Bmax=1.33',linewidth=2)
#ax.plot(mdates,mhs4,'g', label='ww3/CFSR ST4 Bmax=1.70',linewidth=2)
plt.legend(loc=2)
ax.xaxis.set_major_formatter( DateFormatter('%d %HZ') )    
plt.xlabel('time (day - Hour)'); plt.ylabel('Significant Wave Height (m)')
plt.gca().set_ylim(ymin=-0.1); fig.tight_layout(); ax.axis('tight')
plt.gca().set_xlim(left=mdates.min(), right=mdates.max()); plt.grid()
plt.savefig('Assessment_buoy42040_Katrina.png', dpi=300, facecolor='w', edgecolor='w',orientation='portrait', papertype=None, format='png',transparent=False, bbox_inches='tight', pad_inches=0.1)

plt.show()

