#!/bin/sh

PATH=$PATH:/homes/metogra/wavesdemo/ww3/wwatch3.v5.16/bin
export PATH
PATH=$PATH:/homes/metogra/wavesdemo/ww3/wwatch3.v5.16/exe
export PATH
#
module load mpi
export WWATCH3_NETCDF=NC4
export NETCDF_CONFIG=/usr/lib64/openmpi/bin/nc-config

