#!/bin/sh

# 0. Preparations -----------------------------------------------------------
# Avoid problems with RAM memory
ulimit -s unlimited
# ww3 environment
ww3_env='/homes/metogra/wavesdemo/ww3/wwatch3.v5.16/wwatch3.env'                       
# Set Path for WW3
MAIN="/homes/metogra/wavesdemo/ww3/wwatch3.v5.16"          # directory where ww3 is installed
# Time resolution (in seconds) for the outputs:
timer='3600'
# Number of outputs (duration divided by the resolution above plus 1)
ntime='37'
# Flags Grid Output DPT CUR WND HS T0M1 FP DP PHS PTP PDIR
flago='HS FP DP'
# initial date, final date and restart dates
date_ini="20050828 120000"
date_end="20050830 000000"
date_resi="20050830 000000"
namewind='wnd10m.gdas.200508.nc'
restartname='restart.2005082812'

path_e="${MAIN}/exe"                  # ww3 path for executables
path_b="${MAIN}/bin"                  # ww3 path for binaries
path_w='/data/op/waves/Day3/Tutorial/input' # ww3 path where grids, wind and initial conditions are saved


# Clean-up
${path_b}/w3_clear
rm -f log.* mod_def.* ww3_prep.inp* ww3_shel.* out_* test* restart.ww3 wind.*

echo ' ======================== ' 
echo '  Tutorial Gulf of Mexico '
echo ' ======================== ' 

# 1. Grid pre-processor -----------------------------------------------------

  echo ' '
  echo '+-------------------------+'
  echo '|  Grid preprocessor      |'
  echo '+-------------------------+'
  echo ' '

cat > ww3_grid.inp << EOF
$ -------------------------------------------------------------------- $
$ WAVEWATCH III Grid preprocessor input file                           $
$ -------------------------------------------------------------------- $
  'Gulf of Mexico         '
$
   1.1  0.06623  29  24  0.5
   F T T T F T
$
$   900. 300. 450. 10.
   1800. 900. 1350. 15.
$
  &MISC FLAGTR = 2 /
$  &SIN4 BETAMAX = 1.33 /
END OF NAMELISTS
$
   'RECT' T 'NONE'
   77 	 53 
   15.00 	 15.00 	 60.00 
   262.0000 	   18.0000 	  1.00
$ Bottom Bathymetry 
   -0.10   2.50  40  0.001000  1  1 '(....)'  NAME  'gom_15m.depth' 
$ Sub-grid information 
   50  0.010000  1  1  '(....)'  NAME  'gom_15m.obstr'  
$ Mask Information 
   60  1  1  '(....)'  NAME  'gom_15m.mask'  
$
     0.    0.    0.    0.       0
$ -------------------------------------------------------------------- $
$ End of input file                                                    $
$ -------------------------------------------------------------------- $
EOF

 ln -s ${path_w}/gom_15m.depth
 ln -s ${path_w}/gom_15m.obstr
 ln -s ${path_w}/gom_15m.mask
 ${path_e}/ww3_grid
 rm -f ww3_grid.inp

# Initial conditions -----------------------------------------------------
  echo ' ' 
  echo '+--------------------+'  
  echo '| Initial conditions |'  
  echo '+--------------------+'  
  echo ' '  

cat > ww3_strt.inp << EOF
$ WAVEWATCH III Initial conditions input file
$ -------------------------------------------
  3
$
EOF

  if [ -f ${path_w}/${restartname} ]
  then
    echo "   The restart file was found"
    ln -sf ${path_w}/${restartname} restart.ww3
  else
    echo "   The restart file wasn't found"
    echo "   Running ww3_strt for initial conditions"
    ${path_e}/ww3_strt
  fi

 rm -f ww3_strt.inp
# --------------------------------------------------------------------

# 2. Grid pre-processor PRNC for wind
  echo ' '
  echo '+--------------------------+' 
  echo '|  Input preprocessor WIND |' 
  echo '+--------------------------+' 
  echo ' '

cat > ww3_prnc.inp << EOF

  'WND' 'LL' T T
  longitude latitude
  UGRD_10maboveground VGRD_10maboveground
  ${namewind}
EOF

  ln -fs ${path_w}/${namewind}
  ${path_e}/ww3_prnc
 rm -f ww3_prnc.inp

# 3. Run the model
  echo ' ' 
  echo '+------------------------------------+' 
  echo '|   Running the model WW3 SHEL       |' 
  echo '+------------------------------------+'  
  echo ' ' 

cat > ww3_shel.inp << EOF
$ -------------------------------------------------------------------- $
$ WAVEWATCH III shell input file                                       $
$ -------------------------------------------------------------------- $
$ Define input to be used with flag for use and flag for definition
$ as a homogeneous field; four input lines.
$ 1) Water levels
$ 2) Currents
$ 3) Winds
$ 4) Ice concentrations (cannot be homogeneous).
$ 5,6,7)  Assimilation data
   F F
   F F
   T F
   F
   F
   F
   F
$
$ Time frame of calculations ----------------------------------------- $
$ - Starting time in yyyymmdd hhmmss format.
$ - Ending time in yyyymmdd hhmmss format.
$
   20050828 120000
   20050830 000000
$
   1
$
$ Define output data ------------------------------------------------- $
$ Five output types are available (see below). All output types share
$ a similar format for the first input line:
$ - first time in yyyymmdd hhmmss format, output interval (s), and 
$   last time in yyyymmdd hhmmss format (all integers).
$ Output is disabled by setting the output interval to 0.
$
$          Fields of mean wave parameters
$          Standard line and line with flags to activate output fields
$          as defined in section 2.4 of the manual. The second line is
$          not supplied if no output is requested.
$                               The raw data file is out_grd.ww3, 
$                               see w3iogo.ftn for additional doc.
$
   20050828 120000  3600  20050830 000000
$
  N
  HS FP DP
$
$         Point output
$          Standard line and a number of lines identifying the 
$          longitude, latitude and name (C*10) of output points.
$          The list is closed by defining a point with the name
$          'STOPSTRING'. No point info read if no point output is
$          requested (i.e., no 'STOPSTRING' needed).
$                               The raw data file is out_pnt.ww3, 
$                               see w3iogo.ftn for additional doc.
$
   20050828 120000  3600  20050830 000000
$
    271.774 29.208 'NDBC42040'
     0.0   0.0  'STOPSTRING'
$
$ Output along  track.
   20050828 120000     0  20050830 000000
$ Restart files (no additional data required). The data file is restartN.ww3, see w3iors.ftn for additional doc.
   20050830 000000     0  20050830 000000
$ Boundary data (no additional data required). The data file is nestN.ww3, see w3iobp.ftn for additional doc.
   20050828 120000     0  20050830 000000
$ Separated wave field data (dummy for now)
   20050828 120000     0  20050830 000000
$
   'STP'
$ -------------------------------------------------------------------- $
$ End of input file                                                    $
$ -------------------------------------------------------------------- $
EOF
 ${path_e}/ww3_shel
 rm -f ww3_shel.inp

# 4. Gridded output ---------------------------------------------------------
 echo ' ' 
 echo '+--------------------------+' 
 echo "|   Grid NetCDF output     |" 
 echo '+--------------------------+' 
 echo ' ' 

cat > ww3_ounf.inp << EOF
$ WAVEWATCH III - Output fields netcdf
$
  20050828 120000 3600 37
$
  N
$
  HS FP DP
$
    4 4
    0 1 2
    F
$
ww3.
 8
   1 999 1 999 1
$
EOF

 ${path_e}/ww3_ounf 
 rm -f ww3_ounf.inp

# 5.1. Point output / spectrum ---------------------------------------------------------
 echo ' ' 
 echo '+------------------------------------+'   
 echo '|   Spectral NetCDF Point output     |'   
 echo '+------------------------------------+'   
 echo ' '  

cat > ww3_ounp.inp << EOF
$ WAVEWATCH III NETCDF Point output post-processing
$
  20050828 120000 3600 37
$
-1
$
ww3.
 8
 4
 T 150
 1
 0
 T
 3 1. 0.  
$
EOF

 ${path_e}/ww3_ounp
 rm -f ww3_ounp.inp

# 5.2 Point output / Table of parameters ---------------------------------------------------------
  echo ' '
  echo '+-----------------------------------------+'
  echo '|    Point output Table of Parameters     |' 
  echo '+-----------------------------------------+' 
  echo ' ' 

cat > ww3_outp.inp << EOF
$ WAVEWATCH III Point output post-processing
$ ------------------------------------------
 20050828 120000 3600 37
$
 1
$  
 -1
$ 
 2
$ 
 2  50 
$
EOF

 ${path_e}/ww3_outp
 rm -f ww3_outp.inp

